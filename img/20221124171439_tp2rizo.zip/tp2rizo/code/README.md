# ecoleMagie

## Liens
https://e2295331.webdev.cmaisonneuve.qc.ca/tp2ecolemagie/

## Glossaire du Moldu
### Modifier => Potion de polynectar! (potion qui modifie l’apparence)
### Confirmer => Obliviate (sort qui fait oublier)
### Supprimer => Avada Kedavra (sort qui tue)
